<?php
$GLOBALS["env"]="YVY";
?>
