<?php
	session_start(); 
	$_SESSION["upwd"]="";
    header("location:admin.php");
?>